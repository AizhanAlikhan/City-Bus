from django.db import models
from django.contrib.auth.models import User
from account.models import Profile
from django.urls import reverse
import random
# Create your models here.


VEHICLE_TYPE_CHOICES = (('Bus', 'Bus'), ('Trolley bus', 'Trolley bus'))


class Bus_Stop(models.Model):
    name = models.CharField(max_length=100, default='')

    def __str__(self):
        return self.name


class Vehicle(models.Model):
    v_type = models.CharField(max_length=20, choices=VEHICLE_TYPE_CHOICES, default='Bus')
    number = models.CharField(max_length=10, default='')
    stops = models.ManyToManyField(Bus_Stop, related_name='vehicles')

    def __str__(self):
        return self.number + ' ' + self.v_type

    def get_abaolute_url(self):
        return reverse('stops', args=[self.number, self.v_type])
