from django.shortcuts import render, redirect
from . import models
from .forms import SearchForm, TransferForm
# Create your views here.


def base_view(request):
    user = request.user
    return render(request, 'base.html', {'user': user})


def routes(request):
    vehicles = models.Vehicle.objects.all().order_by('number')
    searched_vehicles = None
    if 'query' in request.GET:
        form = SearchForm(request.GET)
        if form.is_valid():
            query = form.cleaned_data['query']
            searched_vehicles = vehicles.filter(number__icontains=query)
            return render(request, 'search.html', {'form': form, 'vehicles': searched_vehicles})
    else:
        form = SearchForm()
        return render(request, 'search.html', {'form': form})


def bus_stops(request, number, v_type):
    vehicle = models.Vehicle.objects.get(number=number, v_type=v_type)
    return render(request, 'stops.html', {'vehicle': vehicle, 'stops': vehicle.stops})
